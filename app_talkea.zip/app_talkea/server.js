const express = require('express');
const session = require('express-session');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const methodOverride = require('method-override');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuración
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(session({
    secret: 'talkea-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// Base de datos
const db = new sqlite3.Database('./database/talkea.db');

// Middleware para pasar datos de usuario a las vistas
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.userColors = {
        'user': '#2E86AB',
        'educator': '#A23B72',
        'admin': '#F18F01'
    };
    // Pasamos los query params a res.locals para usarlos en las vistas EJS
    // Esto es para los mensajes de éxito/error
    res.locals.queryString = req.url.split('?')[1] || '';
    next();
});

// Middleware de autenticación
function requireAuth(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Middleware para requerir rol específico (CORREGIDO)
function requireRole(role) {
    return (req, res, next) => {
        if (!req.session.user) {
            return res.redirect('/login');
        }

        // Admin tiene acceso a todo
        if (req.session.user.user_type === 'admin') {
            return next();
        }

        // Verificar el rol específico
        if (req.session.user.user_type === role) {
            return next();
        }

        // Si no es admin y no es el rol, denegar acceso
        res.status(403).render('pages/error', {
            error: 'Acceso Denegado',
            message: 'No tienes permisos para acceder a esta página.'
        });
    };
}

// ================= RUTAS PÚBLICAS =================
app.get('/', (req, res) => {
    res.render('pages/bienvenida');
});

app.get('/login', (req, res) => {
    const message = req.query.message;
    res.render('pages/login', { message });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM users WHERE username = ? AND is_banned = 0', [username], (err, user) => {
        if (err) {
            console.error('Error en login:', err);
            return res.status(500).render('pages/login', { error: 'Error del servidor' });
        }

        if (user && bcrypt.compareSync(password, user.password)) {
            req.session.user = user;
            console.log(` Login exitoso: ${user.username} (${user.user_type})`);

            if (user.user_type === 'admin') {
                res.redirect('/admin');
            } else {
                res.redirect('/cursos');
            }
        } else {
            console.log(` Login fallido: ${username}`);
            res.render('pages/login', { error: 'Usuario o contraseña incorrectos' });
        }
    });
});

app.get('/registro', (req, res) => {
    res.render('pages/registro');
});

// CORREGIDO: Asegura que los nuevos usuarios SIEMPRE se creen como 'user'
app.post('/registro', (req, res) => {
    const { username, email, password, full_name, phone, curp } = req.body;

    if (!username || !email || !password) {
        return res.render('pages/registro', { error: 'Usuario, email y contraseña son obligatorios' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    db.run(`INSERT INTO users (username, email, password, full_name, phone, curp, user_type)
    VALUES (?, ?, ?, ?, ?, ?, 'user')`,
           [username, email, hashedPassword, full_name, phone, curp],
           function(err) {
               if (err) {
                   console.error('Error en registro:', err);
                   if (err.message.includes('UNIQUE constraint failed')) {
                       return res.render('pages/registro', { error: 'El usuario o correo ya existe' });
                   }
                   return res.render('pages/registro', { error: 'Error al crear usuario' });
               }
               console.log(` Nuevo usuario registrado: ${username} (tipo: user)`);
               res.redirect('/login?message=Usuario creado correctamente. Ya puedes iniciar sesión.');
           }
    );
});

app.get('/logout', (req, res) => {
    console.log(` Logout: ${req.session.user?.username}`);
    req.session.destroy();
    res.redirect('/');
});

// ================= RUTAS PROTEGIDAS =================
app.get('/cursos', requireAuth, (req, res) => {
    console.log(` ${req.session.user.username} accediendo a cursos`);

    db.all(`
    SELECT c.*,
    (SELECT COUNT(*) FROM user_progress up
    JOIN modules m ON up.module_id = m.id
    WHERE up.user_id = ? AND m.course_id = c.id) as completed_modules,
    (SELECT COUNT(*) FROM modules WHERE course_id = c.id) as total_modules
    FROM courses c
    WHERE c.is_active = 1
    GROUP BY c.id
    `, [req.session.user.id], (err, courses) => {
        if (err) {
            console.error('Error cargando cursos:', err);
            return res.status(500).send('Error al cargar cursos');
        }

        res.render('pages/cursos', {
            user: req.session.user,
            courses: courses || []
        });
    });
});

app.get('/perfil', requireAuth, (req, res) => {
    db.get('SELECT educator_request FROM users WHERE id = ?', [req.session.user.id], (err, userData) => {
        if (err) {
            console.error('Error cargando perfil:', err);
            return res.status(500).send('Error al cargar perfil');
        }

        res.render('pages/perfil', {
            user: req.session.user,
            // Asegura que educator_request sea 0 si userData es null
            educator_request: userData ? userData.educator_request : 0
        });
    });
});

app.post('/solicitar-educador', requireAuth, (req, res) => {
    if (req.session.user.user_type !== 'user') {
        return res.redirect('/perfil');
    }

    db.run('UPDATE users SET educator_request = 1 WHERE id = ?', [req.session.user.id], (err) => {
        if (err) {
            console.error('Error solicitando educador:', err);
            return res.redirect('/perfil?error=Error al enviar solicitud');
        }

        req.session.user.educator_request = 1;
        console.log(` Solicitud educador enviada: ${req.session.user.username}`);
        res.redirect('/perfil?message=Solicitud enviada correctamente. Espera la aprobación del administrador.');
    });
});

app.get('/buscar', requireAuth, (req, res) => {
    const searchQuery = req.query.q || '';

    if (searchQuery) {
        db.all(`
        SELECT * FROM courses
        WHERE is_active = 1
        AND (title LIKE ? OR description LIKE ? OR category LIKE ?)
        `, [`%${searchQuery}%`, `%${searchQuery}%`, `%${searchQuery}%`], (err, courses) => {
            if (err) {
                console.error('Error en búsqueda:', err);
                return res.status(500).send('Error en la búsqueda');
            }
            res.render('pages/buscar', {
                user: req.session.user,
                courses: courses,
                searchQuery: searchQuery
            });
        });
    } else {
        db.all('SELECT * FROM courses WHERE is_active = 1 LIMIT 10', (err, courses) => {
            if (err) {
                console.error('Error cargando cursos para búsqueda:', err);
                return res.status(500).send('Error al cargar cursos');
            }
            res.render('pages/buscar', {
                user: req.session.user,
                courses: courses || [],
                searchQuery: ''
            });
        });
    }
});

// ================= SISTEMA DE CURSOS =================

// ---
// ¡AQUÍ ESTÁ LA CORRECCIÓN!
// Poner /curso/nuevo ANTES de /curso/:id
// ---

// Ruta para mostrar el formulario de crear curso (para educadores/admin)
app.get('/curso/nuevo', requireAuth, (req, res) => {
    if (req.session.user.user_type !== 'educator' && req.session.user.user_type !== 'admin') {
        console.log(` Intento de crear curso sin permisos: ${req.session.user.username}`);
        return res.status(403).render('pages/error', { error: 'Acceso Denegado', message: 'Solo educadores y administradores pueden crear cursos.' });
    }

    res.render('pages/curso-nuevo', { user: req.session.user });
});

// Ruta para procesar el formulario de crear curso
app.post('/curso/nuevo', requireAuth, (req, res) => {
    if (req.session.user.user_type !== 'educator' && req.session.user.user_type !== 'admin') {
        return res.status(403).send('Acceso denegado');
    }

    const { title, description, category } = req.body;

    if (!title || !description || !category) {
        return res.render('pages/curso-nuevo', {
            user: req.session.user,
            error: 'Todos los campos son obligatorios'
        });
    }

    db.run('INSERT INTO courses (title, description, category, educator_id) VALUES (?, ?, ?, ?)',
           [title, description, category, req.session.user.id],
           function(err) {
               if (err) {
                   console.error('Error creando curso:', err);
                   return res.render('pages/curso-nuevo', {
                       user: req.session.user,
                       error: 'Error al crear curso'
                   });
               }

               const courseId = this.lastID;
               console.log(` Nuevo curso creado: "${title}" por ${req.session.user.username}`);

               const modules = req.body.modules || [];
               // Filtra módulos vacíos
               const validModules = modules.filter(m => m.title && m.title.trim() !== '');
               let modulesCreated = 0;
               const totalModulesToCreate = validModules.length;

               if (totalModulesToCreate > 0) {
                   validModules.forEach((module, index) => {
                       db.run('INSERT INTO modules (course_id, title, content_type, content, external_link, order_index) VALUES (?, ?, ?, ?, ?, ?)',
                              [courseId, module.title, module.content_type || 'text', module.content || '', module.external_link || '', index + 1],
                              function(err) {
                                  if (err) {
                                      console.error('Error creando módulo:', err);
                                  } else {
                                      console.log(` Módulo creado: "${module.title}"`);
                                  }
                                  modulesCreated++;
                                  // Redirige solo cuando el último módulo se haya procesado
                                  if (modulesCreated === totalModulesToCreate) {
                                      res.redirect(`/curso/${courseId}`);
                                  }
                              }
                       );
                   });
               } else {
                   // Si no hay módulos, redirige inmediatamente
                   res.redirect(`/curso/${courseId}`);
               }
           }
    );
});

// Ruta para ver detalle de curso (AHORA VA DESPUÉS DE /curso/nuevo)
app.get('/curso/:id', requireAuth, (req, res) => {
    const courseId = req.params.id;

    db.get('SELECT * FROM courses WHERE id = ? AND is_active = 1', [courseId], (err, course) => {
        if (err || !course) {
            console.log(` Curso no encontrado: ${courseId}`);
            return res.status(404).render('pages/error', { error: 'Curso no encontrado', message: 'El curso que buscas no existe o fue desactivado.' });
        }

        db.all(`
        SELECT m.*,
        EXISTS(SELECT 1 FROM user_progress WHERE user_id = ? AND module_id = m.id) as completed
        FROM modules m
        WHERE m.course_id = ?
        ORDER BY m.order_index
        `, [req.session.user.id, courseId], (err, modules) => {
            if (err) {
                console.error('Error cargando módulos:', err);
                return res.status(500).send('Error al cargar módulos');
            }

            const completedModules = modules.filter(m => m.completed).length;
            const progress = modules.length > 0 ? (completedModules / modules.length) * 100 : 0;

            res.render('pages/curso-detalle', {
                user: req.session.user,
                course: course,
                modules: modules,
                progress: progress
            });
        });
    });
});

// Ruta para completar un módulo
app.post('/curso/:courseId/modulo/:moduleId/completar', requireAuth, (req, res) => {
    const { courseId, moduleId } = req.params;

    db.run('INSERT OR IGNORE INTO user_progress (user_id, module_id) VALUES (?, ?)',
           [req.session.user.id, moduleId],
           function(err) {
               if (err) {
                   console.error('Error completando módulo:', err);
               } else {
                   console.log(` Módulo completado: usuario ${req.session.user.username}, módulo ${moduleId}`);
               }
               res.redirect(`/curso/${courseId}`);
           }
    );
});

// Ruta para añadir un módulo a un curso existente
app.post('/curso/:id/modulo', requireAuth, (req, res) => {
    const courseId = req.params.id;

    db.get('SELECT * FROM courses WHERE id = ?', [courseId], (err, course) => {
        if (err || !course) {
            return res.status(404).send('Curso no encontrado');
        }

        // Solo el educador del curso o un admin pueden añadir módulos
        if (course.educator_id !== req.session.user.id && req.session.user.user_type !== 'admin') {
            return res.status(403).send('Acceso denegado');
        }

        const { title, content_type, content, external_link } = req.body;

        if (!title) {
            return res.redirect(`/curso/${courseId}?error=El título del módulo es obligatorio`);
        }

        db.get('SELECT MAX(order_index) as max_order FROM modules WHERE course_id = ?', [courseId], (err, result) => {
            const nextOrder = (result.max_order || 0) + 1;

            db.run('INSERT INTO modules (course_id, title, content_type, content, external_link, order_index) VALUES (?, ?, ?, ?, ?, ?)',
                   [courseId, title, content_type, content, external_link, nextOrder],
                   function(err) {
                       if (err) {
                           console.error('Error añadiendo módulo:', err);
                           return res.redirect(`/curso/${courseId}?error=Error al crear módulo`);
                       }
                       console.log(` Módulo añadido al curso ${courseId}: "${title}"`);
                       res.redirect(`/curso/${courseId}?success=Módulo creado correctamente`);
                   }
            );
        });
    });
});

// ================= SISTEMA DE FOROS =================
app.get('/curso/:id/foro', requireAuth, (req, res) => {
    const courseId = req.params.id;

    db.get('SELECT * FROM courses WHERE id = ?', [courseId], (err, course) => {
        if (err || !course) {
            return res.status(404).render('pages/error', { error: 'Curso no encontrado', message: 'El curso que buscas no existe.' });
        }

        db.all(`
        SELECT cf.*, u.username as author_name,
        (SELECT COUNT(*) FROM forum_posts WHERE forum_id = cf.id) as post_count,
               (SELECT MAX(created_at) FROM forum_posts WHERE forum_id = cf.id) as last_activity
               FROM course_forums cf
               JOIN users u ON cf.created_by = u.id
               WHERE cf.course_id = ? AND cf.is_active = 1
               ORDER BY cf.created_at DESC
               `, [courseId], (err, forums) => {
                   if (err) {
                       console.error('Error cargando foros:', err);
                       return res.status(500).send('Error al cargar foros');
                   }

                   res.render('pages/foro', {
                       user: req.session.user,
                       course: course,
                       forums: forums || []
                   });
               });
    });
});

app.post('/curso/:id/foro', requireAuth, (req, res) => {
    const courseId = req.params.id;
    const { title, description } = req.body;

    if (!title) {
        return res.redirect(`/curso/${courseId}/foro?error=El título del foro es obligatorio`);
    }

    db.run('INSERT INTO course_forums (course_id, title, description, created_by) VALUES (?, ?, ?, ?)',
           [courseId, title, description, req.session.user.id],
           function(err) {
               if (err) {
                   console.error('Error creando foro:', err);
                   return res.redirect(`/curso/${courseId}/foro?error=Error al crear foro`);
               }
               console.log(` Nuevo foro creado: "${title}" en curso ${courseId}`);
               res.redirect(`/curso/${courseId}/foro/${this.lastID}`);
           }
    );
});

app.get('/curso/:courseId/foro/:forumId', requireAuth, (req, res) => {
    const { courseId, forumId } = req.params;

    db.get(`
    SELECT cf.*, c.title as course_title, u.username as author_name
    FROM course_forums cf
    JOIN courses c ON cf.course_id = c.id
    JOIN users u ON cf.created_by = u.id
    WHERE cf.id = ? AND cf.course_id = ?
    `, [forumId, courseId], (err, forum) => {
        if (err || !forum) {
            return res.status(404).render('pages/error', { error: 'Foro no encontrado', message: 'El foro que buscas no existe.' });
        }

        db.all(`
        SELECT fp.*, u.username as author_name, u.user_type
        FROM forum_posts fp
        JOIN users u ON fp.user_id = u.id
        WHERE fp.forum_id = ?
        ORDER BY fp.created_at ASC
        `, [forumId], (err, posts) => {
            if (err) {
                console.error('Error cargando posts del foro:', err);
                return res.status(500).send('Error al cargar posts');
            }

            res.render('pages/foro-detalle', {
                user: req.session.user,
                course: { id: courseId, title: forum.course_title },
                forum: forum,
                    posts: posts || []
            });
        });
    });
});

app.post('/curso/:courseId/foro/:forumId', requireAuth, (req, res) => {
    const { courseId, forumId } = req.params;
    const { content } = req.body;

    if (!content || content.trim() === '') {
        return res.redirect(`/curso/${courseId}/foro/${forumId}?error=El mensaje no puede estar vacío`);
    }

    db.run('INSERT INTO forum_posts (forum_id, user_id, content) VALUES (?, ?, ?)',
           [forumId, req.session.user.id, content],
           function(err) {
               if (err) {
                   console.error('Error publicando en foro:', err);
               } else {
                   console.log(` Mensaje publicado en foro ${forumId} por ${req.session.user.username}`);
               }
               res.redirect(`/curso/${courseId}/foro/${forumId}`);
           }
    );
});

// ================= SISTEMA DE CHAT GRUPAL =================
app.get('/curso/:id/chat', requireAuth, (req, res) => {
    const courseId = req.params.id;

    db.get('SELECT * FROM courses WHERE id = ?', [courseId], (err, course) => {
        if (err || !course) {
            return res.status(404).render('pages/error', { error: 'Curso no encontrado', message: 'El curso que buscas no existe.' });
        }

        db.get('SELECT * FROM users WHERE id = ?', [course.educator_id], (err, educator) => {
            res.render('pages/chat', {
                user: req.session.user,
                course: course,
                educator: educator
            });
        });
    });
});

// ================= PANEL DE ADMINISTRACIÓN =================
app.get('/admin', requireAuth, requireRole('admin'), (req, res) => {
    console.log(` Admin access: ${req.session.user.username}`);

    db.get('SELECT COUNT(*) as total_users FROM users', (err, usersCount) => {
        db.get('SELECT COUNT(*) as total_courses FROM courses WHERE is_active = 1', (err, coursesCount) => {
            db.get('SELECT COUNT(*) as pending_requests FROM users WHERE educator_request = 1', (err, requestsCount) => {
                db.get('SELECT COUNT(*) as banned_users FROM users WHERE is_banned = 1', (err, bannedCount) => {

                    db.all('SELECT * FROM users WHERE educator_request = 1', (err, pendingRequests) => {
                        db.all('SELECT * FROM users ORDER BY created_at DESC LIMIT 10', (err, recentUsers) => {

                            res.render('pages/admin/dashboard', {
                                user: req.session.user,
                                stats: {
                                    users: usersCount ? usersCount.total_users : 0,
                                    courses: coursesCount ? coursesCount.total_courses : 0,
                                    pending: requestsCount ? requestsCount.pending_requests : 0,
                                    banned: bannedCount ? bannedCount.banned_users : 0
                                },
                                pendingRequests: pendingRequests || [],
                                recentUsers: recentUsers || []
                            });
                        });
                    });
                });
            });
        });
    });
});

app.get('/admin/usuarios', requireAuth, requireRole('admin'), (req, res) => {
    db.all('SELECT * FROM users ORDER BY created_at DESC', (err, users) => {
        if (err) {
            console.error('Error cargando usuarios para admin:', err);
            return res.status(500).send('Error al cargar usuarios');
        }

        res.render('pages/admin/usuarios', {
            user: req.session.user,
            users: users || [],
            filter: req.query.filter // Pasa el filtro a la vista
        });
    });
});

app.post('/admin/usuario/:id/tipo', requireAuth, requireRole('admin'), (req, res) => {
    const userId = req.params.id;
    const { user_type } = req.body;

    if (!['user', 'educator', 'admin'].includes(user_type)) {
        return res.redirect('/admin/usuarios?error=Tipo de usuario inválido');
    }

    db.run('UPDATE users SET user_type = ?, educator_request = 0 WHERE id = ?',
           [user_type, userId],
           function(err) {
               if (err) {
                   console.error('Error actualizando tipo de usuario:', err);
                   return res.redirect('/admin/usuarios?error=Error al actualizar usuario');
               }
               console.log(` Tipo de usuario cambiado: ID ${userId} -> ${user_type}`);
               res.redirect('/admin/usuarios?success=Usuario actualizado correctamente');
           }
    );
});

app.post('/admin/usuario/:id/ban', requireAuth, requireRole('admin'), (req, res) => {
    const userId = req.params.id;
    const { action } = req.body;

    const isBanned = action === 'ban' ? 1 : 0;

    db.run('UPDATE users SET is_banned = ? WHERE id = ?', [isBanned, userId], function(err) {
        if (err) {
            console.error('Error baneando/desbaneando usuario:', err);
            return res.redirect('/admin/usuarios?error=Error al actualizar usuario');
        }
        console.log(` Usuario ${userId} ${isBanned ? 'baneado' : 'desbaneado'}`);
        res.redirect('/admin/usuarios?success=Usuario actualizado correctamente');
    });
});

app.post('/admin/usuario/:id/password', requireAuth, requireRole('admin'), (req, res) => {
    const userId = req.params.id;
    const { new_password } = req.body;

    if (!new_password || new_password.length < 4) {
        return res.redirect('/admin/usuarios?error=La contraseña debe tener al menos 4 caracteres');
    }

    const hashedPassword = bcrypt.hashSync(new_password, 10);

    db.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, userId], function(err) {
        if (err) {
            console.error('Error cambiando contraseña:', err);
            return res.redirect('/admin/usuarios?error=Error al cambiar contraseña');
        }
        console.log(` Contraseña cambiada para usuario ${userId}`);
        res.redirect('/admin/usuarios?success=Contraseña actualizada correctamente');
    });
});

app.get('/admin/cursos', requireAuth, requireRole('admin'), (req, res) => {
    db.all(`
    SELECT c.*, u.username as educator_name
    FROM courses c
    JOIN users u ON c.educator_id = u.id
    ORDER BY c.created_at DESC
    `, (err, courses) => {
        if (err) {
            console.error('Error cargando cursos para admin:', err);
            return res.status(500).send('Error al cargar cursos');
        }

        res.render('pages/admin/cursos', {
            user: req.session.user,
            courses: courses || []
        });
    });
});

app.delete('/admin/curso/:id', requireAuth, requireRole('admin'), (req, res) => {
    const courseId = req.params.id;

    // Usamos is_active = 0 para desactivar en lugar de borrar
    db.run('UPDATE courses SET is_active = 0 WHERE id = ?', [courseId], function(err) {
        if (err) {
            console.error('Error desactivando curso:', err);
            return res.redirect('/admin/cursos?error=Error al desactivar curso');
        }
        console.log(` Curso desactivado: ${courseId}`);
        res.redirect('/admin/cursos?success=Curso desactivado correctamente');
    });
});

// ================= DIAGNÓSTICO Y DEBUG =================
app.get('/debug/user', requireAuth, (req, res) => {
    res.json({
        sessionUser: req.session.user,
        userType: req.session.user.user_type,
        userId: req.session.user.id,
        isAuthenticated: !!req.session.user
    });
});

// ================= MANEJO DE ERRORES =================
// Ruta 404 (Debe ir al final de todas las rutas)
app.use((req, res) => {
    res.status(404).render('pages/error', {
        error: 'Página no encontrada (404)',
                           message: `La página que buscas (${req.path}) no existe.`
    });
});

// Ruta 500 (Manejador de errores general)
app.use((err, req, res, next) => {
    console.error(' Error del servidor:', err.stack);
    res.status(500).render('pages/error', {
        error: 'Error del servidor (500)',
                           message: 'Algo salió mal en el servidor. Por favor, intenta más tarde.'
    });
});

// ================= INICIALIZACIÓN DEL SERVIDOR =================
app.listen(PORT, () => {
    console.log(' ==========================================');
    console.log(' TALKEA - Plataforma Educativa');
    console.log(' ==========================================');
    console.log(` Servidor ejecutándose en: http://localhost:${PORT}`);
    console.log(' Usuario administrador: admin / cugdl');
    console.log(' Usuario educador: educador / educador123');
    console.log(' Panel admin: http://localhost:3000/admin');
    console.log(' Cursos: http://localhost:3000/cursos');
    console.log(' ==========================================');
});
