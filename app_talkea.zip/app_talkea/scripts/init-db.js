const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const fs = require('fs');

const dbPath = path.join(__dirname, '../database/talkea.db');

// ---
// CORRECCIÓN 1: Eliminar la base de datos existente para recrearla limpia
// ---
if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
    console.log(' Base de datos anterior eliminada');
}

const db = new sqlite3.Database(dbPath);

// Crear tablas en serie para evitar problemas
db.serialize(() => {
    console.log(' Creando tablas...');

    // Tabla de usuarios
    db.run(`CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
                                email VARCHAR(100) UNIQUE NOT NULL,
                                password VARCHAR(255) NOT NULL,
                                user_type VARCHAR(20) DEFAULT 'user' CHECK(user_type IN ('user', 'educator', 'admin')),
                                full_name VARCHAR(100),
                                phone VARCHAR(20),
                                curp VARCHAR(18),
                                educator_request BOOLEAN DEFAULT 0,
                                is_banned BOOLEAN DEFAULT 0,
                                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`, (err) => {
        if (err) console.error('Error creando tabla users:', err);
        else console.log(' Tabla users creada');
    });

        // Tabla de cursos
        db.run(`CREATE TABLE courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(255) NOT NULL,
                                      description TEXT,
                                      category VARCHAR(100),
                                      educator_id INTEGER NOT NULL,
                                      is_active BOOLEAN DEFAULT 1,
                                      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                      FOREIGN KEY (educator_id) REFERENCES users (id)
        )`, (err) => {
            if (err) console.error('Error creando tabla courses:', err);
            else console.log(' Tabla courses creada');
        });

            // Tabla de módulos
            db.run(`CREATE TABLE modules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                course_id INTEGER NOT NULL,
                title VARCHAR(255) NOT NULL,
                                          content_type VARCHAR(20) DEFAULT 'text' CHECK(content_type IN ('text', 'video', 'link', 'document')),
                                          content TEXT,
                                          external_link VARCHAR(500),
                                          order_index INTEGER NOT NULL,
                                          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                          FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
            )`, (err) => {
                if (err) console.error('Error creando tabla modules:', err);
                else console.log(' Tabla modules creada');
            });

                // Tabla de progreso de usuarios
                db.run(`CREATE TABLE user_progress (
                    user_id INTEGER NOT NULL,
                    module_id INTEGER NOT NULL,
                    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, module_id),
                                                    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                                                    FOREIGN KEY (module_id) REFERENCES modules (id) ON DELETE CASCADE
                )`, (err) => {
                    if (err) console.error('Error creando tabla user_progress:', err);
                    else console.log(' Tabla user_progress creada');
                });

                    // Tabla de foros por curso
                    db.run(`CREATE TABLE course_forums (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        course_id INTEGER NOT NULL,
                        title VARCHAR(255) NOT NULL,
                                                        description TEXT,
                                                        created_by INTEGER NOT NULL,
                                                        is_active BOOLEAN DEFAULT 1,
                                                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                                        FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE,
                                                        FOREIGN KEY (created_by) REFERENCES users (id)
                    )`, (err) => {
                        if (err) console.error('Error creando tabla course_forums:', err);
                        else console.log(' Tabla course_forums creada');
                    });

                        // Tabla de posts en foros
                        db.run(`CREATE TABLE forum_posts (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            forum_id INTEGER NOT NULL,
                                user_id INTEGER NOT NULL,
                                content TEXT NOT NULL,
                                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                FOREIGN KEY (forum_id) REFERENCES course_forums (id) ON DELETE CASCADE,
                                                          FOREIGN KEY (user_id) REFERENCES users (id)
                        )`, (err) => {
                            if (err) console.error('Error creando tabla forum_posts:', err);
                            else console.log(' Tabla forum_posts creada');
                        });

                            // Tabla de notificaciones
                            db.run(`CREATE TABLE notifications (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                user_id INTEGER NOT NULL,
                                title VARCHAR(255) NOT NULL,
                                                                message TEXT NOT NULL,
                                                                is_read BOOLEAN DEFAULT 0,
                                                                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                                                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
                            )`, (err) => {
                                if (err) console.error('Error creando tabla notifications:', err);
                                else console.log(' Tabla notifications creada');
                            });

                                // Tabla de mensajes directos
                                db.run(`CREATE TABLE direct_messages (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    sender_id INTEGER NOT NULL,
                                    receiver_id INTEGER NOT NULL,
                                    message TEXT NOT NULL,
                                    is_read BOOLEAN DEFAULT 0,
                                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                    FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE CASCADE,
                                                                      FOREIGN KEY (receiver_id) REFERENCES users (id) ON DELETE CASCADE
                                )`, (err) => {
                                    if (err) console.error('Error creando tabla direct_messages:', err);
                                    else console.log(' Tabla direct_messages creada');
                                });

                                    // Esperar a que se creen todas las tablas antes de insertar datos
                                    setTimeout(() => {
                                        console.log(' Insertando usuarios...');

                                        // Insertar usuario administrador por defecto
                                        const hashedPassword = bcrypt.hashSync('cugdl', 10);
                                        db.run(`INSERT INTO users (username, email, password, user_type, full_name)
                                        VALUES (?, ?, ?, ?, ?)`,
                                               ['admin', 'admin@talkea.edu', hashedPassword, 'admin', 'Administrador TALKEA'],
                                               function(err) {
                                                   if (err) {
                                                       console.error(' Error creando usuario admin:', err);
                                                   } else {
                                                       console.log(' Usuario admin creado: admin / cugdl (tipo: admin)');

                                                       // Insertar un usuario educador de ejemplo
                                                       const educatorPassword = bcrypt.hashSync('educador123', 10);
                                                       db.run(`INSERT INTO users (username, email, password, user_type, full_name)
                                                       VALUES (?, ?, ?, ?, ?)`,
                                                              ['educador', 'educador@talkea.edu', educatorPassword, 'educator', 'Educador Ejemplo'],
                                                              function(err) {
                                                                  if (err) {
                                                                      console.error('Error creando usuario educador:', err);
                                                                  } else {
                                                                      console.log(' Usuario educador creado: educador / educador123 (tipo: educator)');
                                                                      // Crear cursos
                                                                      createSampleCourses();
                                                                  }
                                                              }
                                                       );
                                                   }
                                               }
                                        );
                                    }, 1000); // Espera 1 segundo para asegurar que las tablas existan
});

function createSampleCourses() {
    console.log(' Creando cursos de ejemplo...');

    // Curso 1 - Primeros Auxilios (del educador)
    db.run(`INSERT INTO courses (title, description, category, educator_id)
    VALUES (?, ?, ?, ?)`,
           ['Primeros Auxilios Básicos', 'Aprende técnicas esenciales de primeros auxilios.', 'Salud', 2], // ID 2 es 'educador'
           function(err) {
               if (err) {
                   console.error('Error creando curso 1:', err);
               } else {
                   const course1Id = this.lastID;
                   console.log(' Curso "Primeros Auxilios Básicos" creado');

                   // Módulos para el primer curso
                   db.run(`INSERT INTO modules (course_id, title, content_type, content, order_index)
                   VALUES (?, ?, ?, ?, ?)`,
                          [course1Id, 'Introducción a primeros auxilios', 'text', 'Conceptos básicos.', 1]);
                   db.run(`INSERT INTO modules (course_id, title, content_type, content, external_link, order_index)
                   VALUES (?, ?, ?, ?, ?, ?)`,
                          [course1Id, 'RCP - Video tutorial', 'video', 'Técnica de Reanimación.', 'https://www.youtube.com/watch?v=example_rcp', 2]);
                   db.run(`INSERT INTO modules (course_id, title, content_type, content, external_link, order_index)
                   VALUES (?, ?, ?, ?, ?, ?)`,
                          [course1Id, 'Material de apoyo', 'link', 'Guía PDF.', 'https://drive.google.com/file/example_guia', 3]);
               }
           }
    );

    // Curso 2 - Finanzas Personales (del admin)
    db.run(`INSERT INTO courses (title, description, category, educator_id)
    VALUES (?, ?, ?, ?)`,
           ['Finanzas Personales Inteligentes', 'Aprende a manejar tu dinero.', 'Finanzas', 1], // ID 1 es 'admin'
           function(err) {
               if (err) {
                   console.error('Error creando curso 2:', err);
               } else {
                   const course2Id = this.lastID;
                   console.log(' Curso "Finanzas Personales Inteligentes" creado');

                   // Módulos para el segundo curso
                   db.run(`INSERT INTO modules (course_id, title, content_type, content, order_index)
                   VALUES (?, ?, ?, ?, ?)`,
                          [course2Id, 'Creación de presupuesto', 'text', 'Cómo crear un presupuesto.', 1]);
                   db.run(`INSERT INTO modules (course_id, title, content_type, content, external_link, order_index)
                   VALUES (?, ?, ?, ?, ?, ?)`,
                          [course2Id, 'Herramientas de ahorro', 'link', 'Calculadoras online.', 'https://www.condusef.gob.mx', 2]);
               }
           }
    );
    console.log(' Base de datos inicializada correctamente!');
    console.log(' Usuarios disponibles:');
    console.log(' Admin: admin / cugdl (tipo: admin)');
    console.log(' Educador: educador / educador123 (tipo: educator)');
    console.log(' Nuevos usuarios se crearán como: user');
}

// Cerrar la base de datos después de 5 segundos
setTimeout(() => {
    db.close();
    console.log(' Base de datos cerrada');
}, 5000);
